//
//  Full_CalculatorApp.swift
//  Full Calculator
//
//  Created by Student on 19.11.2021.
//

import SwiftUI

@main
struct Full_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
